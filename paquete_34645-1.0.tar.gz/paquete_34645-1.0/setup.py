from setuptools import setup

setup(
    name="paquete_34645",
    version="1.0",
    description="Paquete de la comision 34645",
    author="la comi 34645",

    packages=["paquete"],
)