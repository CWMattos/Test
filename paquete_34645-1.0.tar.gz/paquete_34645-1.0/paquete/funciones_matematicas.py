def restar(a,b):
    return a-b

def sumar(a,b):
    return a+b

def multiplicar(a,b):
    return a*b

def maximo(a,b):
    if a>b:
       return a
    else:
        return b

pi=3.141592654

