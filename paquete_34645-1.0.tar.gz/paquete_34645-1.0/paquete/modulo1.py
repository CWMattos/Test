
def funcion_paquete():
    print("Esto es una funcion del paquete")

def funcion_paquete2():
    print("Esto es otra funcion del paquete")